//
//  exeViewController.swift
//  elderly_health
//
//  Created by Man sum Chiu on 14/11/2018.
//  Copyright © 2018 Man sum Chiu. All rights reserved.
//

import UIKit

class exeViewController: UIViewController {

    @IBOutlet var run_button: UIButton!
    @IBOutlet var hee_button: UIButton!
    @IBOutlet var ste_button: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        run_button.layer.cornerRadius = 50
        hee_button.layer.cornerRadius = 50
        ste_button.layer.cornerRadius = 50
        
         self.view.backgroundColor = UIColor(patternImage: (UIImage(named: "bg.png") ?? nil)!)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
