//
//  weatherViewController.swift
//  elderly_health
//
//  Created by Man sum Chiu on 1/11/2018.
//  Copyright © 2018 Man sum Chiu. All rights reserved.
//

import UIKit
import BRYXBanner

class weatherViewController: UIViewController {
    
    @IBOutlet var humidity_label: UILabel!
    @IBOutlet var temp_label: UILabel!
    @IBOutlet var max_temp_label: UILabel!
    @IBOutlet var min_temp_label: UILabel!
    @IBOutlet var wind_label: UILabel!
    @IBOutlet var pressure_label: UILabel!
    @IBOutlet var bring_label: UITextView!
    
    @IBOutlet var weatherImage: UIImageView!
    
    let key:String = "&APPID=0edbdf98e16ba46b25fe7e7bb1fd6a24"
    
    override func viewDidLoad() {
        super.viewDidLoad()
         self.view.backgroundColor = UIColor(patternImage: (UIImage(named: "bg.png") ?? nil)!)
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let url = URL(string: "http://api.openweathermap.org/data/2.5/weather?lat=22.29&lon=114.16"+key)!
        
        let task = URLSession.shared.dataTask(with: url){
            data, response, error in
            if let error = error{
                DispatchQueue.main.async {
                    print("Error:\(error.localizedDescription)")
                }
                return
            }
            let data = data!
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                print(json) // json results are printed fine here
                
                let totDictionary = try! JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String: Any]
                if let mainDictionary = totDictionary!["main"] as? [String: Any], let windDictionary = totDictionary!["wind"] as? [String: Any], let cloudsDictionary = totDictionary!["clouds"] as? [String: Any]{
                    
                    var temp: Double = 0
                    var humid: Double = 0
                    var wind_speed: Double = 0
                    var cloud: Double = 0
                    
                    let temp_inK = mainDictionary["temp"] as? Double
                    let temp_inC = temp_inK! - 272.15
                    
                    let min_temp_inK = mainDictionary["temp_min"] as? Double
                    let min_temp_inC = min_temp_inK! - 272.15
                    
                    let max_temp_inK = mainDictionary["temp_max"] as? Double
                    let max_temp_inC = max_temp_inK! - 272.15
                    
                    temp = temp_inC
                    humid = (mainDictionary["humidity"] as? Double)!
                    wind_speed = (windDictionary["speed"] as? Double)!
                    cloud = (cloudsDictionary["all"] as? Double)!
                    
                    DispatchQueue.main.async {
                        self.temp_label.text? = "Average Temperature:" + String(format: "%.00f", temp_inC) + "°C"
                        self.max_temp_label.text? = "Max Temperature:" + String(format: "%.00f", max_temp_inC) + "°C"
                        self.min_temp_label.text? = "Min Temperature:" + String(format: "%.00f", min_temp_inC) + "°C"
                        self.humidity_label.text? = "Humidity: \(String(describing: mainDictionary["humidity"]!)) %"
                        self.wind_label.text? = "Wind Speed: \(String(format: "%.2f", windDictionary["speed"]! as! Double)) m/s"
                        self.pressure_label.text? = "Pressure: \(String(describing: mainDictionary["pressure"]!)) hPa"
                        self.weatherImage.image = UIImage(named: self.getImageName(Temp: temp))
                        self.getbringtips(Temp: temp, Wind: wind_speed, Cloud: cloud)
                        let banner = Banner(title: "Elderly Health", subtitle: self.gettips(Temp: temp, Humid: humid, Wind: wind_speed, Cloud: cloud), image: UIImage(named: "Icon"), backgroundColor: UIColor(red:48.00/255.0, green:174.0/255.0, blue:51.5/255.0, alpha:1.000))
                        banner.dismissesOnTap = true
                        banner.show(duration: 3.0)
                    }
                }
                
            }
            catch{
                print("error in fetching")
            }
            
            guard let response = response as? HTTPURLResponse, response.statusCode == 200
                else{
                    DispatchQueue.main.async {
                        print("Server Error")
                    }
                    return
            }
        }
        task.resume()

    }

    func getbringtips(Temp:Double, Wind:Double,Cloud:Double){
        var tips = "What you should bring today: \n"
        
        if((Wind >= 11.11 && Wind < 16.67) || Temp <= 25){
            tips = tips + "Remeber to bring a jacket with you! \n"
        }
        
        if(Cloud >= 50){
            tips = tips + "Remeber to bring an umbrella with you! \n"
        }
     
        bring_label.text = tips
    }

    
    func gettips(Temp:Double, Humid:Double, Wind:Double,Cloud:Double)->String{
        var tips = "Today's Health Tips: \n"
        
        if (Temp >= 35.0){
            tips = tips + "Today is very hot! Remeber to drink more water and stay indoor! \n"
        }else if(Temp >= 30.0 && Temp < 35.0){
            tips = tips + "Today is hot! Remeber to drink more water and stay indoor! \n"
        }else if(Temp >= 22.0 && Temp < 30.0){
             tips = tips + "Today's temperature is normal! \n"
        }else if(Temp >= 16.0 && Temp < 22.0){
             tips = tips + "Today is cool! Remeber to bring a jacket with you! \n"
        }else {
             tips = tips + "Today is very cold! Remeber to wear more clothes! \n"
        }
        
        if (Humid >= 70){
            if(Temp >= 35){
                tips = tips + "Today is humid! Be careful to heat dissipation\n"
            }else{
                 tips = tips + "Today is humid! \n"
            }
        }else if(Humid >= 55 && Humid < 70){
            tips = tips + "Today's humidity is comfortable! \n"
        }else{
            tips = tips + "Today is too dry! Remeber to drink more water! \n"
        }
        
        if(Wind >= 11.11 && Wind < 16.67){
             tips = tips + "Today's wind speed is high! Remeber to bring a jacket with you! \n"
        }else if(Wind >= 16.67){
            tips = tips + "Today has a typhoon! Remeber stay indoor \n"
        }
        
        if(Cloud >= 50){
            tips = tips + "Today is cloudy! \n"
        }else if(Cloud < 20){
            tips = tips + "Today is clear sky!\n"
        }
        
        return tips
    }
    
    func getImageName(Temp: Double) -> String{
        var imagefile: String = ""
        
        if (Temp >= 35.0){
            imagefile = "hot.png"
        }else if(Temp >= 25.0 && Temp < 35.0){
            imagefile = "hot.png"
        }else if(Temp >= 22.0 && Temp < 25.0){
            imagefile = "hot.png"
        }else if(Temp >= 16.0 && Temp < 22.0){
            imagefile = "wind.png"
        }else{
            imagefile = "cold.png"
        }
        
        return imagefile
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
