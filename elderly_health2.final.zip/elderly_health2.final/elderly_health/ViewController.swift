//
//  ViewController.swift
//  elderly_health
//
//  Created by Man sum Chiu on 29/9/2018.
//  Copyright © 2018年 Man sum Chiu. All rights reserved.
//

import UIKit
import ChameleonFramework

class ViewController: UIViewController {
    
    @IBOutlet var wea_button: UIButton!
    @IBOutlet var exe_button: UIButton!
    @IBOutlet var med_button: UIButton!
    
    
    let healthKitManager = HealthKitManager.sharedInstance
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor(patternImage: (UIImage(named: "bg.png") ?? nil)!)
        // Do any additional setup after loading the view, typically from a nib.
        
        
        healthKitManager.authorizeHealthKit { (success, error) in
            print("HealthKit authorized? \(success)")
        }

        navigationController?.navigationBar.barTintColor = UIColor.flatRed
        wea_button.layer.cornerRadius = 50
        exe_button.layer.cornerRadius = 50
        med_button.layer.cornerRadius = 50
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

