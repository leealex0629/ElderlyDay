//
//  newsViewController.swift
//  elderly_health
//
//  Created by Tsun Lai Lee on 8/11/2018.
//  Copyright © 2018 Man sum Chiu. All rights reserved.
//

import UIKit
import WebKit

class newsViewController: UIViewController {

    @IBOutlet var mWebView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let mURL = URL(string:"https://www.scmp.com/news/hong-kong/health-environment")!
        let request = URLRequest(url: mURL)
        mWebView.load(request)

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
