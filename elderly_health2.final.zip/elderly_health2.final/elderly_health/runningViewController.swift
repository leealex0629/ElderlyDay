//
//  runningViewController.swift
//  elderly_health
//
//  Created by Man sum Chiu on 14/11/2018.
//  Copyright © 2018 Man sum Chiu. All rights reserved.
//

import UIKit
import CoreMotion
import HealthKit

class runningViewController: UIViewController, HeartRateDelegate {
    let healthKitManager = HealthKitManager.sharedInstance
    var heartRateQuery: HKQuery?
    
    @IBOutlet var start_button: UIButton!
    @IBOutlet var reset_button: UIButton!
    @IBOutlet var view_button: UIButton!
    
    
    @IBOutlet var state_label: UILabel!
    @IBOutlet var distance_label: UILabel!
    @IBOutlet var time_label: UILabel!
    @IBOutlet var heartrate_label: UILabel!
    @IBOutlet var state_image: UIImageView!
    
    let activityManager = CMMotionActivityManager()
    let pedoMeter = CMPedometer()
    let motionManager = CMMotionManager()
    
    var timer = Timer()
    var counter = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        start_button.layer.cornerRadius = 50
        reset_button.layer.cornerRadius = 50
        view_button.layer.cornerRadius = 50
         self.view.backgroundColor = UIColor(patternImage: (UIImage(named: "bg.png") ?? nil)!)
    }
    
    @objc func updateCounter() {
        counter += 0.1
        time_label.text = "Time: " + timeString(time:counter)
    }
    
    func timeString(time: Double) -> String {
        let hours = Int(time) / 3600
        let minutes = Int(time) / 60 % 60
        let seconds = Int(time) % 60
        return String(format:"%02i:%02i:%02i", hours, minutes, seconds)
    }
    
    @IBAction func click_start(_ sender: UIButton) {
        if sender.titleLabel?.text == "Start running"{
            retrieveHeartRateData()
            startTrackingActivityType()
            startCountingStep()
            counter = 0.0
            timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
            sender.setTitle("Stop running", for: .normal)
        }else{
            timer.invalidate()
            pedoMeter.stopUpdates()
            motionManager.startDeviceMotionUpdates()
            
            let recordsObject = UserDefaults.standard.object(forKey: "records")
            var records:[String]
            
            let datesObject = UserDefaults.standard.object(forKey: "dates")
            var dates:[String]
            
            let date = Date()
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            let stringDate: String = formatter.string(from: date)
            
            if let temprecords = recordsObject as? [String]{
                records = temprecords
                records.append("\(distance_label.text!)\n\(time_label.text!)\n\(heartrate_label.text!)")
                print(records)
            }else{
                records = ["\(distance_label.text!)\n\(time_label.text!)\n\(heartrate_label.text!)"]
            }
            
            if let tempdates = datesObject as? [String]{
                dates = tempdates
                dates.append(stringDate)
                print(dates)
            }else{
                dates = [stringDate]
            }
            
            UserDefaults.standard.set(records, forKey: "records")
            UserDefaults.standard.set(dates, forKey: "dates")
            
            sender.setTitle("Start running", for: .normal)
        }
    }
    
    @IBAction func click_reset(_ sender: Any) {
        state_label.text = "Current State: "
        distance_label.text = "Distance: "
        time_label.text = "Time: "
        heartrate_label.text = "Heart Rate: "
    }
    
    
    private func startTrackingActivityType(){
        if CMMotionActivityManager.isActivityAvailable() {
            activityManager.startActivityUpdates(to: OperationQueue.main) {
                [weak self] (activity: CMMotionActivity?) in
                guard let activity = activity
                    else { return }
                
                DispatchQueue.main.async {
                    if activity.walking {
                        self?.state_label.text = "Current State:Walking"
                        self?.state_image.image = UIImage(named: "walking.png")
                    } else if activity.stationary {
                        self?.state_label.text = "Current State:Stationary"
                        self?.state_image.image = UIImage(named: "standing.png")
                    } else if activity.running {
                        self?.state_label.text = "Current State:Running"
                        self?.state_image.image = UIImage(named: "running.png")
                    }
                }
            }
        }
    }

    private func startCountingStep() {
        if CMPedometer.isDistanceAvailable() && CMPedometer.isStepCountingAvailable(){
            pedoMeter.startUpdates(from: Date()) {
                [weak self] pedometerData, error in
                guard let pedometerData = pedometerData, error == nil
                    else { return }
                
                DispatchQueue.main.async {
                    self?.distance_label.text = "Distance: \(String(pedometerData.distance as! Double)) m"
                }
                
            }
        }
    }
    
    
    func retrieveHeartRateData() {
        
        if let query = healthKitManager.createHeartRateStreamingQuery(Date()) {
            self.heartRateQuery = query
            self.healthKitManager.heartRateDelegate = self
            self.healthKitManager.healthStore.execute(query)
        }
    }
    
    func heartRateUpdated(heartRateSamples: [HKSample]) {
        
        guard let heartRateSamples = heartRateSamples as? [HKQuantitySample] else {
            return
        }
        
        DispatchQueue.main.async {
            
            guard let sample = heartRateSamples.first else {
                self.heartrate_label.text = "Heart Rate: not working"
                return
            }
            let value = sample.quantity.doubleValue(for: HKUnit(from: "count/min"))
            let heartRateString = String(format: "%.00f", value)
            self.heartrate_label.text = heartRateString
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
