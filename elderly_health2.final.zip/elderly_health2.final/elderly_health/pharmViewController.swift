//
//  pharmViewController.swift
//  elderly_health
//
//  Created by Man sum Chiu on 18/11/2018.
//  Copyright © 2018 Man sum Chiu. All rights reserved.
//

import UIKit

class pharmViewController: UIViewController {

    @IBOutlet var hk: UIButton!
    @IBOutlet var kow: UIButton!
    @IBOutlet var nt: UIButton!
    @IBOutlet var online: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: (UIImage(named: "bg.png") ?? nil)!)
        // Do any additional setup after loading the view.
        
        hk.layer.cornerRadius = 25
        kow.layer.cornerRadius = 25
        nt.layer.cornerRadius = 25
        online.layer.cornerRadius = 25
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
