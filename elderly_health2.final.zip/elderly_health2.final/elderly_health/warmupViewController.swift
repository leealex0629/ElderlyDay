//
//  warmupViewController.swift
//  elderly_health
//
//  Created by Man sum Chiu on 14/11/2018.
//  Copyright © 2018 Man sum Chiu. All rights reserved.
//

import UIKit
import youtube_ios_player_helper


class warmupViewController: UIViewController, YTPlayerViewDelegate {
    @IBOutlet var warm_button: UIButton!
    @IBOutlet var playerView: YTPlayerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        warm_button.layer.cornerRadius = 50
        
         playerView.delegate = self
        let playerVars = ["playsinline": 1] // 0: will play video in fullscreen
        self.playerView.load(withVideoId: "q-_BWXpM-Y0", playerVars: playerVars)
        
         self.view.backgroundColor = UIColor(patternImage: (UIImage(named: "bg.png") ?? nil)!)
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
