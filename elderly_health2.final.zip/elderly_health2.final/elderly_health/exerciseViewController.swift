//
//  exerciseViewController.swift
//  elderly_health
//
//  Created by Man sum Chiu on 7/11/2018.
//  Copyright © 2018 Man sum Chiu. All rights reserved.
//

import UIKit
import CoreMotion

class exerciseViewController: UIViewController {
    
    @IBOutlet var step_label: UILabel!
    @IBOutlet var ascend_label: UILabel!
    @IBOutlet var descend_label: UILabel!
    
    @IBOutlet var target_label: UILabel!

    var days:[String] = []
    var stepsTaken:[Int] = []
  
    let activityManager = CMMotionActivityManager()
    let pedoMeter = CMPedometer()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        var cal = NSCalendar.current
        var comps = cal.dateComponents([.hour, .minute, .second], from: Date())
        comps.hour = 0
        comps.minute = 0
        comps.second = 0
        let timeZone = NSTimeZone.system
        cal.timeZone = timeZone
        
        let midnightOfToday = cal.date(from: comps)!
        
        if(CMPedometer.isStepCountingAvailable()){
            let fromDate = NSDate(timeIntervalSinceNow: -86400 * 7)
            self.pedoMeter.queryPedometerData(from: fromDate as Date, to: NSDate() as Date) { (data : CMPedometerData!, error) -> Void in
                print(data)
                DispatchQueue.main.async {
                    self.step_label.text = "Steps:\(String(data.numberOfSteps.stringValue ))"
                    self.ascend_label.text = "Floors ascended:\(String(data.floorsAscended!.stringValue ))"
                    self.descend_label.text = "Floors descended:\(String(data.floorsDescended!.stringValue ))"
                }
                
            }
            
            self.pedoMeter.startUpdates(from: midnightOfToday) { (data: CMPedometerData!, error) -> Void in
              DispatchQueue.main.async {
                self.step_label.text = "Steps:\(String((Int(truncating: data.numberOfSteps)/7) ))"
                    self.ascend_label.text = "Floors ascended:\(String((Int(truncating: data.floorsAscended!)/7) ))"
                    self.descend_label.text = "Floors descended:\(String((Int(truncating: data.floorsDescended!)/7) ))"
                self.target_label.text = "Target:\(String(10000-(Int(truncating: data.numberOfSteps)/7) )) steps remaining today!!"
                }
            }
        }
         self.view.backgroundColor = UIColor(patternImage: (UIImage(named: "bg.png") ?? nil)!)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
