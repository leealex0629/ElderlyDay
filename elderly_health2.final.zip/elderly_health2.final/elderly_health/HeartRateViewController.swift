//
//  HeartRateViewController.swift
//  elderly_health
//
//  Created by yiu shing kwok on 11/11/2018.
//  Copyright © 2018 Man sum Chiu. All rights reserved.
//

import UIKit
import HealthKit

class HeartRateViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, HeartRateDelegate {
    let healthKitManager = HealthKitManager.sharedInstance
    var datasource: [HKQuantitySample] = []
    var heartRateQuery: HKQuery?
    
    @IBOutlet var heartRateLabel: UILabel!
    @IBOutlet var heartTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.retrieveHeartRateData()

        // Do any additional setup after loading the view.
    }
    
  
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datasource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "heartRate", for: indexPath)
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let stringDate: String = formatter.string(from: date)
        
        cell.textLabel?.text = "\(datasource[indexPath.row].quantity)" + "    " + stringDate
        return cell
    }
    
    func retrieveHeartRateData() {
        
        if let query = healthKitManager.createHeartRateStreamingQuery(Date()) {
            self.heartRateQuery = query
            self.healthKitManager.heartRateDelegate = self
            self.healthKitManager.healthStore.execute(query)
        }
    }
    func heartRateUpdated(heartRateSamples: [HKSample]) {
        
        guard let heartRateSamples = heartRateSamples as? [HKQuantitySample] else {
            return
        }
        
        DispatchQueue.main.async {
            
            self.datasource.append(contentsOf: heartRateSamples)
            self.heartTableView.reloadData()
    }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
