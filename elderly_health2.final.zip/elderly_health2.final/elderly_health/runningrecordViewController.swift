//
//  runningrecordViewController.swift
//  elderly_health
//
//  Created by Man sum Chiu on 14/11/2018.
//  Copyright © 2018 Man sum Chiu. All rights reserved.
//

import UIKit

class runningrecordViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    var records:[String] = []
    var dates:[String] = []

    @IBOutlet var running_table: UITableView!
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dates.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "recordCell", for: indexPath as IndexPath)
        
        cell.textLabel?.text = dates[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let mymsg: String = records[indexPath.row]
        
        let optionMenu = UIAlertController(title: "Reocrds", message: mymsg, preferredStyle: .actionSheet)
        let Cancel = UIAlertAction(title: "Cancel", style: .default, handler: {(alert:UIAlertAction!) -> Void in })
        optionMenu.addAction(Cancel)
        
        self.present(optionMenu, animated: true, completion: nil)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let recordsObject = UserDefaults.standard.object(forKey: "records")
        let datesObject = UserDefaults.standard.object(forKey: "dates")
        
        if let temprecords = recordsObject as? [String]{
            records = temprecords
        }
        
        if let tempdates = datesObject as?[String]{
            dates = tempdates
        }
        
        running_table.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
