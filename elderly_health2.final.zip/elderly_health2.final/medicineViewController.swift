//
//  medicineViewController.swift
//  
//
//  Created by Tsun Lai Lee on 8/11/2018.
//

import UIKit

class medicineViewController: UIViewController {
    
    @IBOutlet var add: UIButton!
    @IBOutlet var day: UIButton!
    @IBOutlet var new: UIButton!
    @IBOutlet var pha: UIButton!
    @IBOutlet var eme: UIButton!
    
    @IBOutlet var itemTextField: UITextField!
    @IBAction func add(_ sender: Any) {
        let itemsObject = UserDefaults.standard.object(forKey: "items")
        var items:[String]
        if let tempItems = itemsObject as? [String] {
            items = tempItems
            items.append(itemTextField.text!)
            print(items)
        } else {
            items = [itemTextField.text!]
        }
        UserDefaults.standard.set(items, forKey: "items")
        itemTextField.text = ""
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
 self.view.backgroundColor = UIColor(patternImage: (UIImage(named: "bg.png") ?? nil)!)
        // Do any additional setup after loading the view.
        
        add.layer.cornerRadius = 25
        day.layer.cornerRadius = 25
        pha.layer.cornerRadius = 25
        new.layer.cornerRadius = 25
        eme.layer.cornerRadius = 25
        
    }
    
    @IBAction func eCall(_ sender: Any) {
        let url: NSURL = URL(string: "TEL://999")! as NSURL
        UIApplication.shared.open(url as URL, options: convertToUIApplicationOpenExternalURLOptionsKeyDictionary([:]), completionHandler: nil)
    }
    
  
    
  
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToUIApplicationOpenExternalURLOptionsKeyDictionary(_ input: [String: Any]) -> [UIApplication.OpenExternalURLOptionsKey: Any] {
	return Dictionary(uniqueKeysWithValues: input.map { key, value in (UIApplication.OpenExternalURLOptionsKey(rawValue: key), value)})
}
